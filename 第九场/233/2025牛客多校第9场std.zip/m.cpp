#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n; cin >> n;
    if (n <= 9) cout << "1\n";
    else cout << "-1\n";
}

int main() {
    int T; cin >> T;
    while(T--) solve();
}