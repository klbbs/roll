/*
    Author: YZB
    Problem:
    Status:
*/
#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
//	freopen("data10.in","r",stdin);
//	freopen("data10.ans","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
	int tc;
	cin>>tc;
	while(tc--){
		int n;
		cin>>n;
		if(n%6==4)cout<<"2\n";
		else cout<<"0\n";
	}
	return 0;
}
/*
asdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirth
asdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirth
asdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirth
asdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirth
asdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirth
asdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirthasdasdeogirth
*/

